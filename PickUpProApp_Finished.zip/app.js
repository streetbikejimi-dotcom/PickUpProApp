
import { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, StatusBar, ActivityIndicator, Alert, Linking } from 'react-native';

const SERVER_URL = 'https://pickuppro-server.onrender.com';

const COLORS = {
  bg: '#08090d', card: '#10111a', border: '#1c1d2e',
  accent: '#f97316', green: '#22c55e', red: '#ef4444',
  yellow: '#eab308', blue: '#3b82f6',
  text: '#f0f2f8', muted: '#64748b', surface: '#161720',
};

const CATEGORIES = [
  { id: 'appliances', icon: '🏠', label: 'Appliances', desc: 'Washers, dryers, fridges, stoves', basePrice: 120, color: '#3b82f6', note: '2-person lift required', items: ['Washer / Dryer', 'Refrigerator', 'Stove / Range', 'Dishwasher', 'AC Unit', 'Water Heater'] },
  { id: 'furniture', icon: '🛋️', label: 'Large Furniture', desc: 'Sofas, beds, dressers, tables', basePrice: 95, color: '#a855f7', note: 'Disassembly available', items: ['Sofa / Couch', 'Bed Frame', 'Mattress', 'Dresser', 'Dining Table', 'Wardrobe'] },
  { id: 'motorcycle', icon: '🏍️', label: 'Motorcycles', desc: 'Sport bikes, cruisers, ATVs', basePrice: 150, color: '#f97316', note: 'Trailer equipped drivers only', items: ['Sport Bike', 'Cruiser', 'Dirt Bike', 'Scooter', 'ATV'] },
  { id: 'compressor', icon: '⚙️', label: 'Equipment', desc: 'Compressors, generators, machinery', basePrice: 130, color: '#22c55e', note: 'Weight limit 800 lbs', items: ['Air Compressor', 'Generator', 'Pressure Washer', 'Welding Equipment'] },
  { id: 'boxes', icon: '📦', label: 'Boxes & Small Items', desc: 'Moving boxes, bags, small items', basePrice: 35, color: '#eab308', note: 'Fast pickup available', items: ['Moving Boxes (1-5)', 'Moving Boxes (6-15)', 'Moving Boxes (16+)', 'Bags / Luggage'] },
  { id: 'outdoor', icon: '🌿', label: 'Outdoor & Garden', desc: 'Mowers, grills, hot tubs', basePrice: 100, color: '#10b981', note: 'Hot tubs need 4-person team', items: ['Riding Lawn Mower', 'BBQ Grill', 'Hot Tub', 'Patio Furniture'] },
];

export default function App() {
  const [tab, setTab] = useState('home');
  const [user, setUser] = useState({ name: '', email: '', phone: '', role: 'both', stripeAccountId: null });

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.bg} />
      <View style={styles.topBar}>
        <Text style={styles.logo}>Pick Up <Text style={{ color: COLORS.accent }}>Pro</Text></Text>
        <Text style={styles.topBarTab}>{{ home: '🏠 Home', request: '📦 Book', driver: '🚗 Drive', profile: '👤 Profile' }[tab]}</Text>
      </View>
      <View style={{ flex: 1 }}>
        {tab === 'home' && <HomeScreen user={user} setTab={setTab} />}
        {tab === 'request' && <RequestScreen user={user} />}
        {tab === 'driver' && <DriverScreen user={user} setUser={setUser} />}
        {tab === 'profile' && <ProfileScreen user={user} setUser={setUser} />}
      </View>
      <View style={styles.navBar}>
        {[['home','🏠','Home'],['request','📦','Book'],['driver','🚗','Drive'],['profile','👤','Profile']].map(([id, icon, label]) => (
          <TouchableOpacity key={id} style={styles.navItem} onPress={() => setTab(id)}>
            <Text style={{ fontSize: 22, opacity: tab === id ? 1 : 0.35 }}>{icon}</Text>
            <Text style={[styles.navLabel, { color: tab === id ? COLORS.accent : COLORS.muted }]}>{label}</Text>
            {tab === id && <View style={styles.navDot} />}
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

function HomeScreen({ user, setTab }) {
  const [serverOk, setServerOk] = useState(null);
  useEffect(() => {
    fetch(SERVER_URL + '/').then(() => setServerOk(true)).catch(() => setServerOk(false));
  }, []);
  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 20, paddingBottom: 100 }}>
      <Text style={styles.greeting}>Welcome back{user.name ? ', ' + user.name.split(' ')[0] : ''} 👋</Text>
      <Text style={styles.title}>Pick Up <Text style={{ color: COLORS.accent }}>Pro</Text></Text>
      <View style={styles.statusRow}>
        <View style={[styles.dot, { backgroundColor: serverOk === null ? COLORS.yellow : serverOk ? COLORS.green : COLORS.red }]} />
        <Text style={styles.statusText}>{serverOk === null ? 'Connecting...' : serverOk ? 'Server online ✓' : 'Server offline'}</Text>
      </View>
      <View style={styles.grid}>
        {[{icon:'📦',label:'Book Pickup',color:COLORS.accent,tab:'request'},{icon:'🚗',label:'Start Driving',color:COLORS.blue,tab:'driver'},{icon:'💰',label:'Earnings',color:COLORS.green,tab:'driver'},{icon:'👤',label:'Profile',color:'#a855f7',tab:'profile'}].map(q => (
          <TouchableOpacity key={q.label} style={styles.quickCard} onPress={() => setTab(q.tab)}>
            <Text style={{ fontSize: 26, marginBottom: 8 }}>{q.icon}</Text>
            <Text style={[styles.quickLabel, { color: q.color }]}>{q.label}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <Text style={styles.sectionTitle}>WHAT WE MOVE</Text>
      <View style={styles.grid}>
        {CATEGORIES.map(cat => (
          <TouchableOpacity key={cat.id} style={styles.catCard} onPress={() => setTab('request')}>
            <Text style={{ fontSize: 22, marginBottom: 6 }}>{cat.icon}</Text>
            <Text style={[styles.catLabel, { color: cat.color }]}>{cat.label}</Text>
            <Text style={styles.catPrice}>from ${cat.basePrice}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}

function RequestScreen({ user }) {
  const [step, setStep] = useState('category');
  const [selectedCat, setSelectedCat] = useState(null);
  const [selectedItem, setSelectedItem] = useState(null);
  const [form, setForm] = useState({ pickup: '', dropoff: '', notes: '', email: user.email || '' });
  const [loading, setLoading] = useState(false);

  const handleBook = async () => {
    if (!form.pickup || !form.dropoff || !form.email) return Alert.alert('Error', 'Please fill in all fields');
    setLoading(true);
    try {
      const res = await fetch(`${SERVER_URL}/create-payment-intent`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: selectedCat.basePrice,
          customerEmail: form.email,
          jobId: `job_${Date.now()}`
        })
      });
      const data = await res.json();
      if (data.clientSecret) {
        Alert.alert('Success', 'Payment intent created! In a real app, we would now show the Stripe Payment Sheet.');
        setStep('category');
      } else {
        throw new Error(data.error || 'Failed to create payment');
      }
    } catch (err) {
      Alert.alert('Error', err.message);
    } finally {
      setLoading(false);
    }
  };

  if (step === 'category') {
    return (
      <ScrollView style={styles.screen}>
        <Text style={styles.sectionTitle}>SELECT CATEGORY</Text>
        {CATEGORIES.map(cat => (
          <TouchableOpacity key={cat.id} style={styles.listCard} onPress={() => { setSelectedCat(cat); setStep('item'); }}>
            <Text style={{ fontSize: 24, marginRight: 15 }}>{cat.icon}</Text>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>{cat.label}</Text>
              <Text style={styles.cardDesc}>{cat.desc}</Text>
            </View>
            <Text style={styles.cardPrice}>${cat.basePrice}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    );
  }

  if (step === 'item') {
    return (
      <ScrollView style={styles.screen}>
        <TouchableOpacity onPress={() => setStep('category')} style={styles.backBtn}>
          <Text style={{ color: COLORS.accent }}>← Back to Categories</Text>
        </TouchableOpacity>
        <Text style={styles.sectionTitle}>WHAT ARE WE PICKING UP?</Text>
        {selectedCat.items.map(item => (
          <TouchableOpacity key={item} style={styles.listCard} onPress={() => { setSelectedItem(item); setStep('details'); }}>
            <Text style={styles.cardTitle}>{item}</Text>
            <Text style={{ color: COLORS.accent }}>Select →</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    );
  }

  return (
    <ScrollView style={styles.screen} contentContainerStyle={{ paddingBottom: 40 }}>
      <TouchableOpacity onPress={() => setStep('item')} style={styles.backBtn}>
        <Text style={{ color: COLORS.accent }}>← Back to Items</Text>
      </TouchableOpacity>
      <Text style={styles.sectionTitle}>PICKUP DETAILS</Text>
      <View style={styles.inputGroup}>
        <Text style={styles.label}>Pickup Address</Text>
        <TextInput style={styles.input} placeholder="123 Street Name, City" placeholderTextColor={COLORS.muted} value={form.pickup} onChangeText={t => setForm({...form, pickup: t})} />
      </View>
      <View style={styles.inputGroup}>
        <Text style={styles.label}>Dropoff Address</Text>
        <TextInput style={styles.input} placeholder="456 Destination, City" placeholderTextColor={COLORS.muted} value={form.dropoff} onChangeText={t => setForm({...form, dropoff: t})} />
      </View>
      <View style={styles.inputGroup}>
        <Text style={styles.label}>Contact Email</Text>
        <TextInput style={styles.input} placeholder="your@email.com" placeholderTextColor={COLORS.muted} keyboardType="email-address" value={form.email} onChangeText={t => setForm({...form, email: t})} />
      </View>
      <View style={styles.inputGroup}>
        <Text style={styles.label}>Notes for Driver</Text>
        <TextInput style={[styles.input, { height: 80 }]} multiline placeholder="Gate code, heavy item, etc." placeholderTextColor={COLORS.muted} value={form.notes} onChangeText={t => setForm({...form, notes: t})} />
      </View>
      
      <View style={styles.summaryCard}>
        <Text style={styles.summaryText}>Service: {selectedItem}</Text>
        <Text style={styles.summaryPrice}>Total: ${selectedCat.basePrice}</Text>
      </View>

      <TouchableOpacity style={styles.mainBtn} onPress={handleBook} disabled={loading}>
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.mainBtnText}>Confirm & Pay</Text>}
      </TouchableOpacity>
    </ScrollView>
  );
}

function DriverScreen({ user, setUser }) {
  const [loading, setLoading] = useState(false);
  const [balance, setBalance] = useState({ available: '0.00', pending: '0.00' });

  useEffect(() => {
    if (user.stripeAccountId) {
      fetch(`${SERVER_URL}/driver-balance/${user.stripeAccountId}`)
        .then(res => res.json())
        .then(data => setBalance(data))
        .catch(err => console.log('Balance error:', err));
    }
  }, [user.stripeAccountId]);

  const handleOnboard = async () => {
    if (!user.email) return Alert.alert('Profile Required', 'Please set your email in the Profile tab first.');
    setLoading(true);
    try {
      const res = await fetch(`${SERVER_URL}/onboard-driver`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: user.email, driverId: user.phone || 'driver_1' })
      });
      const data = await res.json();
      if (data.onboardingUrl) {
        setUser({ ...user, stripeAccountId: data.stripeAccountId });
        Linking.openURL(data.onboardingUrl);
      }
    } catch (err) {
      Alert.alert('Error', 'Failed to start onboarding');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.screen}>
      <Text style={styles.sectionTitle}>DRIVER DASHBOARD</Text>
      {!user.stripeAccountId ? (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Become a Pro Driver</Text>
          <Text style={styles.cardDesc}>Earn 80% of every job. We handle the payments, you handle the move.</Text>
          <TouchableOpacity style={styles.mainBtn} onPress={handleOnboard} disabled={loading}>
            {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.mainBtnText}>Setup Payouts with Stripe</Text>}
          </TouchableOpacity>
        </View>
      ) : (
        <View>
          <View style={styles.balanceCard}>
            <Text style={styles.balanceLabel}>Available for Payout</Text>
            <Text style={styles.balanceAmount}>${balance.available}</Text>
            <Text style={styles.pendingText}>Pending: ${balance.pending}</Text>
          </View>
          <TouchableOpacity style={styles.listCard}>
            <Text style={{ fontSize: 24, marginRight: 15 }}>🚛</Text>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>Available Jobs</Text>
              <Text style={styles.cardDesc}>Check for new pickups in your area</Text>
            </View>
          </TouchableOpacity>
        </View>
      )}
    </ScrollView>
  );
}

function ProfileScreen({ user, setUser }) {
  return (
    <ScrollView style={styles.screen}>
      <Text style={styles.sectionTitle}>MY PROFILE</Text>
      <View style={styles.card}>
        <View style={styles.inputGroup}>
          <Text style={styles.label}>Full Name</Text>
          <TextInput style={styles.input} value={user.name} onChangeText={t => setUser({...user, name: t})} placeholder="John Doe" placeholderTextColor={COLORS.muted} />
        </View>
        <View style={styles.inputGroup}>
          <Text style={styles.label}>Email Address</Text>
          <TextInput style={styles.input} value={user.email} onChangeText={t => setUser({...user, email: t})} placeholder="john@example.com" placeholderTextColor={COLORS.muted} keyboardType="email-address" />
        </View>
        <View style={styles.inputGroup}>
          <Text style={styles.label}>Phone Number</Text>
          <TextInput style={styles.input} value={user.phone} onChangeText={t => setUser({...user, phone: t})} placeholder="(555) 000-0000" placeholderTextColor={COLORS.muted} keyboardType="phone-pad" />
        </View>
      </View>
      <Text style={styles.infoText}>Your information is used to coordinate pickups and process payments securely via Stripe.</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  topBar: { paddingHorizontal: 20, paddingTop: 60, paddingBottom: 15, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderBottomWidth: 1, borderBottomColor: COLORS.border },
  logo: { fontSize: 22, fontWeight: '900', color: COLORS.text, letterSpacing: -0.5 },
  topBarTab: { color: COLORS.muted, fontSize: 14, fontWeight: '600' },
  navBar: { flexDirection: 'row', backgroundColor: COLORS.surface, paddingBottom: 30, paddingTop: 12, borderTopWidth: 1, borderTopColor: COLORS.border },
  navItem: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  navLabel: { fontSize: 10, fontWeight: '700', marginTop: 4 },
  navDot: { width: 4, height: 4, borderRadius: 2, backgroundColor: COLORS.accent, marginTop: 4 },
  screen: { flex: 1, padding: 20 },
  greeting: { fontSize: 16, color: COLORS.muted, marginBottom: 4 },
  title: { fontSize: 32, fontWeight: '900', color: COLORS.text, marginBottom: 15 },
  statusRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 25 },
  dot: { width: 8, height: 8, borderRadius: 4, marginRight: 8 },
  statusText: { color: COLORS.muted, fontSize: 13, fontWeight: '500' },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  quickCard: { width: '48%', backgroundColor: COLORS.card, padding: 20, borderRadius: 20, marginBottom: 15, borderWidth: 1, borderColor: COLORS.border },
  quickLabel: { fontSize: 14, fontWeight: '700' },
  sectionTitle: { fontSize: 13, fontWeight: '800', color: COLORS.muted, letterSpacing: 1.5, marginTop: 10, marginBottom: 15 },
  catCard: { width: '31%', backgroundColor: COLORS.card, padding: 12, borderRadius: 16, marginBottom: 12, alignItems: 'center', borderWidth: 1, borderColor: COLORS.border },
  catLabel: { fontSize: 11, fontWeight: '700', textAlign: 'center' },
  catPrice: { fontSize: 10, color: COLORS.muted, marginTop: 4 },
  listCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.card, padding: 18, borderRadius: 20, marginBottom: 12, borderWidth: 1, borderColor: COLORS.border },
  cardTitle: { fontSize: 17, fontWeight: '700', color: COLORS.text },
  cardDesc: { fontSize: 13, color: COLORS.muted, marginTop: 2 },
  cardPrice: { fontSize: 18, fontWeight: '800', color: COLORS.accent },
  backBtn: { marginBottom: 20 },
  inputGroup: { marginBottom: 20 },
  label: { fontSize: 14, fontWeight: '600', color: COLORS.muted, marginBottom: 8 },
  input: { backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.border, borderRadius: 12, padding: 15, color: COLORS.text, fontSize: 16 },
  summaryCard: { backgroundColor: COLORS.surface, padding: 20, borderRadius: 15, marginTop: 10, marginBottom: 25, borderWidth: 1, borderColor: COLORS.accent + '40' },
  summaryText: { color: COLORS.text, fontSize: 16 },
  summaryPrice: { color: COLORS.accent, fontSize: 24, fontWeight: '900', marginTop: 5 },
  mainBtn: { backgroundColor: COLORS.accent, padding: 18, borderRadius: 15, alignItems: 'center' },
  mainBtnText: { color: '#fff', fontSize: 18, fontWeight: '800' },
  card: { backgroundColor: COLORS.card, padding: 20, borderRadius: 20, borderWidth: 1, borderColor: COLORS.border },
  balanceCard: { backgroundColor: COLORS.blue, padding: 25, borderRadius: 25, marginBottom: 20 },
  balanceLabel: { color: 'rgba(255,255,255,0.7)', fontSize: 14, fontWeight: '600' },
  balanceAmount: { color: '#fff', fontSize: 42, fontWeight: '900', marginVertical: 5 },
  pendingText: { color: 'rgba(255,255,255,0.8)', fontSize: 13 },
  infoText: { color: COLORS.muted, fontSize: 13, textAlign: 'center', marginTop: 20, lineHeight: 18 }
});
